/*************** YOU SHOULD NOT MODIFY ANYTHING IN THIS FILE ***************/
int run_smp1_tests(int argc, char **argv);
int main(int argc, char **argv);
