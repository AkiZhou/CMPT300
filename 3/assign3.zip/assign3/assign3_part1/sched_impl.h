#ifndef	__SCHED_IMPL__H__
#define	__SCHED_IMPL__H__

struct thread_info {
	/*...Fill this in...*/
};

struct sched_queue {
	/*...Fill this in...*/
};

#endif /* __SCHED_IMPL__H__ */
