#!/bin/sh
#*************** YOU SHOULD NOT MODIFY ANYTHING IN THIS FILE ***************

rm -rf ./testdata
